package client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    
    private Socket socket;                                                           

    
    public  Client () throws IOException {
        socket = new Socket("localhost", 9876);
    }

    
    public void connect () {

        
        Scanner scanner = new Scanner(System.in);

        try {
            DataInputStream entrada = new DataInputStream(socket.getInputStream());     
            DataOutputStream salida = new DataOutputStream(socket.getOutputStream());   
            System.out.println(entrada.readUTF());                                      
            salida.writeUTF(scanner.nextLine());                                        
            System.out.println(entrada.readUTF());                                      

            int numTareas = Integer.parseInt(scanner.nextLine());                       
            salida.writeInt(numTareas);                                                 

            
            for (int i = 1 ; i <= numTareas; i++){
                System.out.println(entrada.readUTF());                                  
                System.out.println(entrada.readUTF());                                  
                salida.writeUTF(scanner.nextLine());                                    
                System.out.println(entrada.readUTF());                                  
                salida.writeUTF(scanner.nextLine());                                    
            }

            System.out.println(entrada.readUTF());                                      

            
            for (int i = 0; i<numTareas; i++){
                System.out.println(entrada.readUTF());
            }
            salida.close();
            entrada.close();
            socket.close();

        }catch (IOException ex){
            System.err.println("Error a la hora de abrir la conexión");
        }
    }
}
