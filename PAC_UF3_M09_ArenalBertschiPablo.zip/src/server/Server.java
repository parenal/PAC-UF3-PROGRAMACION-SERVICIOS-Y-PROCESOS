package server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    
    private final int PUERTO = 9876;           
    private ServerSocket server;               
    private Socket client;                     
    
    public Server () throws IOException {
        server = new ServerSocket(PUERTO);     
        client = new Socket();                 
    }
    
    public void connect() throws IOException {
        while (true){                          
            client = server.accept();          

            DataInputStream entrada = new DataInputStream(client.getInputStream());
            DataOutputStream salida = new DataOutputStream(client.getOutputStream());
            salida.writeUTF("Bienvenido, ¿Podría indicarme su nombre?");
            System.out.println(entrada.readUTF());
            salida.writeUTF("¿Cuántas tareas tiene usted que realizar?");

           
            int numTareas = entrada.readInt();
            System.out.println(numTareas);

           
            Tarea [] tareas = new Tarea[numTareas];

            
            for (int i = 1; i <= numTareas; i++ ){
                Tarea miTarea = new Tarea();
                salida.writeUTF("Introducción de la tarea: " + i);
                salida.writeUTF("Introduzca la descripción, por favor: ");
                miTarea.setDescription(entrada.readUTF());                 
                salida.writeUTF("Introduzca el estado de la tarea, por favor: ");
                miTarea.setEstado(entrada.readUTF());                      
                tareas[i-1] = miTarea;
            }

            salida.writeUTF("Listado de tareas: ");
            for (int i = 0; i <numTareas; i++){                            
                salida.writeUTF("Tarea: " + tareas[i].getDescription() + ", en estado " + tareas[i].getEstado());
            }
            client.close();
            server.close();
        }
    }
}

